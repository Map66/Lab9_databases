package com.example.myfirstdatabase

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.*
import android.widget.ArrayAdapter
import androidx.appcompat.widget.Toolbar
import androidx.appcompat.app.ActionBarDrawerToggle
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.navigation.NavigationView
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import androidx.drawerlayout.widget.DrawerLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import com.example.myfirstdatabase.databinding.ActivityMainBinding



class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {
    private var mDBAdapter: MyDBAdapter? = null
    private val mAllFaculties = arrayOf("Engineering", "Business", "Arts" )
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initializeViews()
        initializeDatabase()
        loadList()
    }

    override fun onBackPressed() {
        val drawer_layout : DrawerLayout = findViewById(R.id.drawer_layout)
        if (drawer_layout.isDrawerOpen(GravityCompat.START)){
            drawer_layout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        val drawer_layout : DrawerLayout = findViewById(R.id.drawer_layout)
        drawer_layout.closeDrawer(GravityCompat.START)
        return true
    }

    private fun initializeViews(){
        val toolbar : Toolbar? = findViewById(R.id.toolbar)
        val nav_view : NavigationView = findViewById(R.id.nav_view)
        val drawer_layout: DrawerLayout = findViewById(R.id.drawer_layout)
        setSupportActionBar(toolbar)
        val toggle = ActionBarDrawerToggle(this,
            drawer_layout,
            toolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close)
        drawer_layout.addDrawerListener(toggle)
        toggle.syncState()
        nav_view.setNavigationItemSelectedListener(this)
        var faculties_spinner : Spinner = findViewById(R.id.faculties_spinner)
        faculties_spinner.adapter = ArrayAdapter(this@MainActivity,
        android.R.layout.simple_list_item_1,
        mAllFaculties)

        val student_name : EditText = findViewById(R.id.student_name)
        val add_students : Button = findViewById(R.id.add_student)
        add_students.setOnClickListener{
            mDBAdapter?.insertStudent(student_name.text.toString(),
            faculties_spinner.selectedItemPosition + 1)
            loadList()
        }
        val delete_engineer : Button = findViewById(R.id.delete_engineers)
        delete_engineer.setOnClickListener() {
            mDBAdapter?.deleteAllEngineers()
            loadList()
        }
    }

    private fun initializeDatabase(){
        mDBAdapter = MyDBAdapter(this@MainActivity)
        mDBAdapter?.open()
    }

    private fun loadList() {
        val allStudents: List<String>? = mDBAdapter?.selectAllStudents()
        val arrayAllStudents = allStudents?.toTypedArray()!!

        val adapter = ArrayAdapter(
            this@MainActivity,
            android.R.layout.simple_list_item_1,
            arrayAllStudents
        )
        var student_list : ListView = findViewById(R.id.student_list)
        student_list.adapter = adapter
    }
}