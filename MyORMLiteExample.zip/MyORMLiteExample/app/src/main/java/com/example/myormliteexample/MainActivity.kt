package com.example.myormliteexample

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import androidx.appcompat.widget.Toolbar
import androidx.appcompat.app.ActionBarDrawerToggle
import com.google.android.material.navigation.NavigationView
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.drawerlayout.widget.DrawerLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import com.example.myormliteexample.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity(),NavigationView.OnNavigationItemSelectedListener {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding
    private val personDao = PersonDao()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val toolbar : Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        val drawer_layout : DrawerLayout = findViewById(R.id.drawer_layout)
        val nav_view : NavigationView = findViewById(R.id.nav_view)
        val toggle = ActionBarDrawerToggle(
            this, drawer_layout, toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close
        )
        drawer_layout.addDrawerListener(toggle)
        toggle.syncState()
        val addButton : Button = findViewById(R.id.addButton)
        val deleteAllButton : Button = findViewById(R.id.deleteAllButton)
        addButton.setOnClickListener {
            val newRecordInput : EditText = findViewById(R.id.newRecordInput)
            val input = newRecordInput.text.toString()
            if (!input.isEmpty()) {
                personDao.add(Person(null,input))
                loadList()
            }
        }
        deleteAllButton.setOnClickListener {
            personDao.removeAll()
            loadList()
        }
    }

    override fun onBackPressed() {
        val drawer_layout : DrawerLayout = findViewById(R.id.drawer_layout)
        if (drawer_layout.isDrawerOpen(GravityCompat.START)) {
            drawer_layout.closeDrawer(GravityCompat.START)
        } else {
        super.onBackPressed()
    }}

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }

     override fun onNavigationItemSelected(item: MenuItem): Boolean {
        val drawer_layout : DrawerLayout = findViewById(R.id.drawer_layout)
        drawer_layout.closeDrawer(GravityCompat.START)
        return true
    }

    private fun loadList() {
        val allStudents: List<Person>? = personDao.queryForAll()
        val arrayAllStudents = allStudents?.toTypedArray()!!
        val adapter = ArrayAdapter(this@MainActivity,
        android.R.layout.simple_list_item_1,
        arrayAllStudents)
        val recordsList : ListView = findViewById(R.id.recordsList)
        recordsList.adapter = adapter

    }
}